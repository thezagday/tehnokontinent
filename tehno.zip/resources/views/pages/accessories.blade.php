@extends('index')  
@section('content')
@include('_common._banner')
   <div class="container-fluid">
    <div class="row breadcrumb-wrapper">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li>
                    <a href="/">Главная</a>
                </li>
                <li>
                    <a href="catalog">Каталог</a>
                </li>
                <li>
                    <a href="catalog_page">Металлочерепица</a>
                </li>
                <li>
                    <a href="catalog_page">Белорусская</a>
                </li>
                <li class="active">Акссессуары</li>
            </ol>
        </div>
    </div>
</div>
<div class="container-fluid page-content">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-sm-3 view-mode">
                    <a href="catalog_page" class="fa fa-th active"></a>
                    <a href="catalog_page_list" class="hidden-xs fa fa-th-list"></a>
                </div>
                <div class="col-sm-3 filter-products">
                    <p class="font-regular">Показано:
                        <select name="" id="" class="inline-select">
                            <option value="" selected>10</option>
                            <option value="">20</option>
                            <option value="">30</option>
                        </select>
                        <label for="select-count">
                            <b class="caret"></b>
                        </label>
                        из 45
                    </p>
                </div>
                <div class="col-sm-6 filter-products">
                    <p class="font-regular">Сортировать по:
                        <select name="" id="" class="inline-select select-width-auto">
                            <option value="" selected>Цене по возрастанию</option>
                            <option value="">Цене по убыванию</option>
                            <option value="">Названию</option>
                        </select>
                        <label for="select-count">
                            <b class="caret"></b>
                        </label>
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
               
                    @include('_common._menu')
                    
                </div>
                <div class="col-md-9">
                    <div class="row">
                        @if (count($accessories)==0)
                        <div class="col-md-4 product-block">
                            <div>
                                <div class="image-block" style="background-image: url(images/no_photo.gif);">
                                    <a href="product_page?id=">ПОДРОБНЕЕ<span class="fa fa-long-arrow-right"></span></a>
                                </div>
                                <div class="info-block">
                                    <h4>Акссессуаров нет</h4>
                                    <p>от <span class="orange-color"><small>руб./ м.п</small></span></p>
                                </div>
                                <a data-toggle="modal" href="#buy" class="btn btn-warning text-uppercase"><span class="fa fa-shopping-cart"></span>Заказать</a>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        @endif    
                        @foreach ($accessories as $accessory)
                        <div class="col-md-4 product-block">
                            <div>
                                <div class="image-block" style="background-image: url(images/products/product01.jpg);">
                                    <a href="product_page?id={{$accessory->id}}">ПОДРОБНЕЕ<span class="fa fa-long-arrow-right"></span></a>
                                </div>
                                <div class="info-block">
                                    <h4>{{$accessory->title}}</h4>
                                    <p>от <span class="orange-color">{{$accessory->price}}<small>руб./ м.п</small></span></p>
                                </div>
                                <a data-toggle="modal" href="#buy" class="btn btn-warning text-uppercase"><span class="fa fa-shopping-cart"></span>Заказать</a>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="col-md-12 text-center">
                <ul class="pagination">
                    <li><a href="#">&laquo;</a></li>
                    <li><a href="#" class="active">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li><a href="#">&raquo;</a></li>
                </ul>
            </div>
            <div class="clearfix"></div>
            <div class="text-center">
                <div class="seo-text text-left">
                    <h2>{!!$material->title!!}</h2>
                    <p>{!!$material->body!!}</p>
                </div>
            </div>
        </div>
    </div>
</div> 
@stop