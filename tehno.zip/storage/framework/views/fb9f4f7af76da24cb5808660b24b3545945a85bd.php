  
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('_common._banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid">
    <div class="row breadcrumb-wrapper">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li>
                    <a href="index.php">Главная</a>
                </li>
                <li class="active">Сертификаты</li>
            </ol>
        </div>
    </div>
</div>
<div class="container-fluid page-content">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-uppercase">Сертификаты</h1>

            <div class="baguetteBox row">
                <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-sm-6 col-md-4 sert-image-block">
                    <a href="<?php echo e($certificate->img_path); ?>" style="background-image: url('<?php echo e($certificate->prev); ?>');"></a>
                    <p><?php echo $certificate->title; ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="clearfix"></div>
            </div>


            <div class="clearfix"></div>
            <div class="text-center">
                <div class="seo-text text-left">
                    <h2><?php echo $material->title; ?></h2>
                    <p><?php echo $material->body; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>