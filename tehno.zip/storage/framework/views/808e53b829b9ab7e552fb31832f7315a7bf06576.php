  
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('_common._banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-fluid">
    <div class="row breadcrumb-wrapper">
        <div class="col-md-12">
            <ol class="breadcrumb">
            	<li>
            		<a href="/">Главная</a>
            	</li>
            	<li class="active">Акции</li>
            </ol>
        </div>
    </div>
</div>
<div class="container-fluid page-content">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-uppercase">Акции</h1>
            <div class="checkbox filter-check">
            	<label>
            		<input type="checkbox" value="" id="">
            		Только актуальные
            	</label>
            </div>
            <?php $__currentLoopData = $shares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $share): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($share->relevance == 1): ?>
            <div class="col-xs-12 share-block active">
                <div class="share-status">
                    <p>Акция актуальна</p>
                </div>
            <?php else: ?>
            <div class="col-xs-12 share-block">
                <div class="share-status">
                    <p>Акция не актуальна</p>
                </div>
            <?php endif; ?>
                <div class="share-image" style="background-image:url('<?php echo e($share->img_path); ?>');"></div>
                <div class="share-info">
                    <div class="share-header">
                        <h4>
                            <?php echo $share->title; ?>

                        </h4>
                        <div class="share-price">
                            <p>Стоимость от <span class="font-bold"><?php echo $share->price; ?></span></p>
                        </div>
                        <p><?php echo e($share->short_body); ?></p>
                        <a href="share_page?id=<?php echo e($share->id); ?>" class="orange-color more-link">Подробнее об акции<span class="fa fa-long-arrow-right"></span></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="clearfix"></div>
            <div class="col-md-12 text-center">
                <ul class="pagination">
                    <li><a href="#">&laquo;</a></li>
                    <li><a href="#" class="active">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li><a href="#">&raquo;</a></li>
                </ul>
            </div>

            <div class="col-md-12 text-center">
                <div class="row seo-text text-left">
                    <h2><?php echo $material->title; ?></h2>
                    <p><?php echo $material->body; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>