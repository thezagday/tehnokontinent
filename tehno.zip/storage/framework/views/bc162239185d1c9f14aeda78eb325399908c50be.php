<?php if(count($catalogs) > 0 ): ?>
    <ul class="catalog-nav">
    <li><a href="catalogs" class="head-link">Каталог<span><b class="caret"></b></span></a></li>
    <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($catalog->parent == 0): ?>
            <?php echo $__env->make('partials.catalog', $catalog, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <li><a href="accessories" class="head-link">Аксессуары<span><b class="caret"></b></span></a></li>
    </ul>
<?php else: ?>
    
<?php endif; ?>