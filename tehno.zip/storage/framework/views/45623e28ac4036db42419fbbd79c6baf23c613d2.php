  
<?php $__env->startSection('content'); ?>
    <div class="layout-content">
    <div class="layout-content-body">
        <h1 class="title-bar-title">Редактирование "<?php echo e($item_accessories->title); ?>"</h1>
        <p class="title-bar-description">Тут вы можете отредактировать преимущество "<?php echo e($item_accessories->title); ?>"</p>
        <div class="row">
            <div class="col-md-8">
                <div class="demo-form-wrapper">
    <form action="update_item_accessories" method="post" class="form form-horizontal" enctype="multipart/form-data">
    <p>
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" value="<?php echo e($item_accessories->id); ?>"/>
        <div class="form-group">
            <label class="col-sm-3 control-label" for="form-control-1">Заголовок</label>
            <div class="col-sm-9">
                <input id="form-control-1" class="form-control" type="text" name="title" value="<?php echo e($item_accessories->title); ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label" for="form-control-1">Текст</label>
            <div class="col-sm-9">
                <input id="form-control-1" class="form-control" type="text" name="body" value="<?php echo e($item_accessories->body); ?>" >
            </div>
         </div>
         <div class="form-group">
            <label class="col-sm-3 control-label" for="form-control-1">Цена</label>
            <div class="col-sm-9">
                <input id="form-control-1" class="form-control" type="text" name="price" value="<?php echo e($item_accessories->price); ?>" >
            </div>
         </div>
         <div class="form-group">
            <label class="col-sm-3 control-label" for="form-control-1">Картинка</label>
            <div class="col-sm-9">
                <input id="form-control-1" class="form-control" type="text" name="img_path" value="<?php echo e($item_accessories->img_path); ?>" >
                <input type="file" name="img_path">
            </div>
         </div>
  
    </p>
    <div class="form-group">
        <label class="col-sm-3 control-label" for="form-control-1"></label>
        <div class="col-sm-9">
            <button type="submit" class="btn-primary" id="input_btn">Сохранить</button>
        </div>
    </div>
    </form>
  </div>
            </div>
       </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>