  
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('_common._banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid">
    <div class="row breadcrumb-wrapper">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li>
                    <a href="index.php">Главная</a>
                </li>
                <li class="active">Статьи</li>
            </ol>
        </div>
    </div>
</div>
<div class="container-fluid page-content">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-uppercase">Статьи</h1>
            
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 share-block news-block">
                <div class="share-status">
                    <p><span class="fa fa-clock-o"></span> <?php echo e($article->date); ?></p>
                </div>
                <div class="share-image" style="background-image:url('<?php echo e($article->img_path); ?>');"></div>
                <div class="share-info">
                    <div class="share-header">
                        <h4>
                            <?php echo $article->title; ?>

                        </h4>
                        <p><?php echo e($article->short_body); ?></p>
                        <a href="article_page?id=<?php echo e($article->id); ?>" class="orange-color more-link">Подробнее<span class="fa fa-long-arrow-right"></span></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="clearfix"></div>
            <div class="col-md-12 text-center">
                <ul class="pagination">
                    <li><a href="#">&laquo;</a></li>
                    <li><a href="#" class="active">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li><a href="#">&raquo;</a></li>
                </ul>
            </div>
            <div class="col-md-12 text-center">
                <div class="seo-text text-left">
                    <h2><?php echo $material->title; ?></h2>
                    <p><?php echo $material->body; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>