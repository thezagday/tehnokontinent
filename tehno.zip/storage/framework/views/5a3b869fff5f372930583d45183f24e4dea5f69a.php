  
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
		<div class="row main-slider-wrapper">
			<div class="main-slider">
				<div style="background-image:url(<?php echo e(asset('images/slide01.jpg')); ?>)">
					<div class="col-md-12">
						<div class="grey-block">
							<p class="text-uppercase">Только в апреле!</p>
							<h2>Металлочерепица<br>
							по сниженной цене</h2>
						</div>
						<div class="clearfix"></div>
						<div class="price-block">
							<p>от 23<sup>00</sup> <small>руб./м.п.</small></p>
						</div>
						<div class="btn-block">
							<a href="share_page" class="text-uppercase btn btn-default">Подробнее</ahref>
							<a href="" class="text-uppercase btn btn-warning">Купить по акции</a>
						</div>
					</div>
				</div>
				<div style="background-image:url(<?php echo e(asset('images/slide01.jpg')); ?>)">
					<div class="col-md-12">
						<div class="grey-block">
							<p class="text-uppercase">Только в апреле!</p>
							<h2>Металлочерепица<br>
							по сниженной цене</h2>
						</div>
						<div class="clearfix"></div>
						<div class="price-block">
							<p>от 33<sup>50</sup> <small>руб./м.п.</small></p>
						</div>
						<div class="btn-block">
							<a href="share_page" class="text-uppercase btn btn-default">Подробнее</a>
							<a href="" class="text-uppercase btn btn-warning">Купить по акции</a>
						</div>
					</div>
				</div>
			</div>
			<div class="owl-prev">
				<img src="<?php echo e(asset('images/icons/left-arrow.png')); ?>" alt="left">
			</div>
			<div class="owl-next">
				<img src="<?php echo e(asset('images/icons/right-arrow.png')); ?>" alt="right">
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="advantages">
                                        <?php $__currentLoopData = $advantages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advantage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-3">
						<div class="adv-icon">
							<img src="<?php echo e($advantage->img); ?>" alt="icon">
						</div>
						<h5 class="text-uppercase font-bold"><?php echo e($advantage->title); ?></h5>
						<p><?php echo e($advantage->body); ?> </p>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 product-carousel-block">
				<h2 class="title">Хиты продаж</h2>
				<div class="owl-prev fa fa-angle-left"></div>
				<div class="owl-next fa fa-angle-right"></div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-12">
				<div class="product-slider">
                                    <?php if($bestsellers!= null): ?>
                                    <?php $__currentLoopData = $bestsellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
						<div class="image-block" style="background-image: url(<?php echo e(asset('images/products/product01.jpg')); ?>);">
							<a href="product_page?id=<?php echo e($item->id); ?>">ПОДРОБНЕЕ<span class="fa fa-long-arrow-right"></span></a>
						</div>
						<div class="info-block">
							<h4><?php echo $item->title; ?></h4>
							<p>от <span class="orange-color"><?php echo $item->price; ?><small>руб./ м.п</small></span></p>
						</div>
                                            <?php if($item->is_new): ?>
						<div class="status-block status-new">
							<span>Новинка</span>
						</div>
                                            <?php endif; ?>
						<a data-toggle="modal" href="#buy" class="btn btn-warning text-uppercase"><span class="fa fa-shopping-cart"></span>Заказать</a>
					</div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row catalog-block">
			<div class="col-md-12">
				<h2 class="title">Каталог</h2> 
                                  <!--Если каталогов меньше чем 10, то один столбец -->
                                                                    <?php if(($parent_catalogs != null) && (count($parent_catalogs) !=0)&& (count($parent_catalogs)<10)): ?>
                                                                        <div class="col-sm-3">
                                                                            <ul><!-- у них нет родителей но и не обязательно у них есть дети-->
                                                                                <?php for($j = 0; $j < count($parent_catalogs); $j++): ?>
                                                                                    <?php if(DB::table('catalogs')->where('parent',$parent_catalogs[$j]->id)->first()!= null): ?>
                                                                                        <li><a href="catalogs?id=<?php echo e($parent_catalogs[$j]->id); ?>"><?php echo e($parent_catalogs[$j]->title); ?></a></li> <!--У них есть дети-->
                                                                                    <?php else: ?>
                                                                                        <li><a href="products?parent=<?php echo e($parent_catalogs[$j]->id); ?>"><?php echo e($parent_catalogs[$j]->title); ?></a></li><!--У них нет детей-->
                                                                                    <?php endif; ?>
                                                                                <?php endfor; ?>	
                                                                            </ul>   
                                                                        </div>
                                                                    <!--Если каталогов больше чем 10, то расчитывается количество столбцов -->
                                                                    <?php elseif(($parent_catalogs != null) && (count($parent_catalogs)!=0)): ?>
                                                                        <?php echo e($count_catalogs = count($parent_catalogs)); ?>

                                                                        <?php echo e($cols = intval($count_catalogs/10)); ?>

                                                                        <?php echo e($ost = $count_catalogs % 10); ?>

                                                                        <?php echo e($i = 0); ?>

                                                                        <?php echo e($k = 0); ?>

                                                                        <?php echo e($z = 10); ?>

                                                                        <?php while($i <= $cols): ?>
                                                                            <div>
                                                                                <ul>
                                                                                    <?php for($j = $k; $j < $z; $j++): ?>
                                                                                        <?php if(DB::table('catalogs')->where('parent',$parent_catalogs[$j]->id)->first()!= null): ?>
                                                                                            <li><a href="catalogs?id=<?php echo e($parent_catalogs[$j]->id); ?>"><?php echo e($parent_catalogs[$j]->title); ?></a></li> <!--У них есть дети-->
                                                                                        <?php else: ?>
                                                                                            <li><a href="products?parent=<?php echo e($parent_catalogs[$j]->id); ?>"><?php echo e($parent_catalogs[$j]->title); ?></a></li><!--У них нет детей-->
                                                                                        <?php endif; ?>
                                                                                    <?php endfor; ?>		
                                                                                    <?php echo e($k = $j); ?>

                                                                                    <?php echo e($z += 10); ?>

                                                                                    <?php if($z > $count_catalogs): ?>
                                                                                        <?php echo e($z = $z - 10 + $ost); ?>

                                                                                    <?php endif; ?>
                                                                                </ul>   
                                                                            </div>
                                                                                    <?php echo e($i++); ?>

                                                                        <?php endwhile; ?>
                                                                    <?php endif; ?>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row company">
			<div class="col-md-12">
				<h2 class="title">О компании «техноконтинент»</h2>
				<hr><br>
				<div class="row">
					<div class="col-md-3">
						<div class="comment-slider-wrapper">
							<h4 class="font-bold text-center">ОТЗЫВЫ</h4>
							<hr style="border-color:#f0623f;">
							<div class="comment-slider text-center">
                                                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
                                                                <div>
									<div class="comment-block">
										<p><i>“<?php echo e($comment->short_body); ?>"</i></p>
									</div>
									<div class="comment-author">
										<div class="author-image" style="background-image: url('<?php echo e($comment->img_path); ?>');"></div>
										<h4 class="text-uppercase"><?php echo e($comment->name); ?></h4>
										<p style="color:#b8b8b8"><?php echo e($comment->city); ?></p>
									</div>
								</div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<div class="owl-nav text-center">
								<div class="owl-prev fa fa-angle-left"></div>
								<div class="owl-next fa fa-angle-right"></div>
							</div>
							<a href="comments" class="orange-color more-link">Все отзывы<span class="fa fa-long-arrow-right"></span></a>
						</div>
					</div>
					<div class="col-md-9">
						<h2><?php echo $material[0]->title; ?></h2>
						<p><?php echo $material[0]->short_body; ?></p>
						<a href="company" class="orange-color more-link">Читать дальше<span class="fa fa-long-arrow-right"></span></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row question">
			<div class="col-md-12 text-center">
				<p>Не нашли ответ на интересующий вопрос?</p>
				<p>Оставьте ваш номер телефона, и наш специалист с радостью ответит на любой вопрос!</p>
				<br>
				<form action="" method="POST" class="form-inline" role="form">
					<div class="form-group">
						<input type="phone" class="form-control" id="" required="required" placeholder="Номер телефона">
					</div>
					<button type="submit" class="btn btn-default">ЗАКАЗАТЬ БЕСПЛАТНУЮ КОНСУЛЬТАЦИЮ</button>
				</form>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 product-carousel-block post-slider-wrapper">
				<h2 class="title">Статьи</h2>
				<div class="owl-prev fa fa-angle-left"></div>
				<div class="owl-next fa fa-angle-right"></div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-12">
				<div class="post-slider">
                                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="post">
						<div class="image-block" style="background-image: url(<?php echo e(asset('images/post-image.jpg')); ?>);">
							<div class="post-date text-center">
								<b>1</b>
								<hr style="border-color: #f0623f">
								<p>ИЮН</p>
							</div>
						</div>
						<div class="info-block">
							<h4><?php echo $article->title; ?></h4>
							<p><br>Расшифровка того, о чем описывается в статье</p>
							<a href="article_page?id=<?php echo e($article->id); ?>" class="orange-color more-link">Читать далее<span class="fa fa-long-arrow-right"></span></a>
						</div>
					</div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-md-12 text-center">
				<div class="seo-text text-left">
					<h1><?php echo $material[1]->title; ?></h1>
					<p><?php echo $material[1]->body; ?></p>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row partners">
			<div class="col-md-12 partners-wrapper">
				<div class="owl-prev fa fa-angle-left"></div>
				<div class="owl-next fa fa-angle-right"></div>
				<div class="partners-slider">
					<div><img src="<?php echo e(asset('images/partners/8824310-fedex-logo-650-a542d8629a-1484575865.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/google_logo_2015.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo_blum.png')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo-kronospan.png')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/8824310-fedex-logo-650-a542d8629a-1484575865.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/google_logo_2015.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo_blum.png')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo-kronospan.png')); ?>" alt="logo"></div><div><img src="images/partners/8824310-fedex-logo-650-a542d8629a-1484575865.jpg" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/google_logo_2015.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo_blum.png')); ?>" alt="logo"></div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>