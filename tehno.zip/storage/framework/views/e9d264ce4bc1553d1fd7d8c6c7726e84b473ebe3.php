<?php if(DB::table('catalogs')->where('parent',$catalog->id)->first()!= null): ?>
    <li><a href="#"><?php echo e($catalog->title); ?></a>
<?php else: ?>
    <li><a href="products?parent=<?php echo e($catalog->id); ?>"><?php echo e($catalog->title); ?></a>
<?php endif; ?>
<?php if(count(App\Catalogs::find($catalog->id)->get_childrens) > 0): ?>
	    <ul>
	    <?php $__currentLoopData = App\Catalogs::find($catalog->id)->get_childrens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <?php echo $__env->make('partials.catalog', $catalog, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </ul>
<?php endif; ?>	
</li>