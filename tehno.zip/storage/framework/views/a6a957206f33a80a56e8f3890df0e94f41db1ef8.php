<?php if(count($catalogs) > 0 ): ?>
    <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($catalog->parent == 0): ?>
            <?php echo $__env->make('partials.admin_catalog', $catalog, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    
<?php endif; ?>