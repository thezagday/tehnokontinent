  
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
		<div class="row main-slider-wrapper">
			<div class="main-slider">
				<div style="background-image:url(<?php echo e(asset('images/slide01.jpg')); ?>)">
					<div class="col-md-12">
						<div class="grey-block">
							<p class="text-uppercase">Только в апреле!</p>
							<h2>Металлочерепица<br>
							по сниженной цене</h2>
						</div>
						<div class="clearfix"></div>
						<div class="price-block">
							<p>от 23<sup>00</sup> <small>руб./м.п.</small></p>
						</div>
						<div class="btn-block">
							<a href="share-page.php" class="text-uppercase btn btn-default">Подробнее</ahref>
							<a href="" class="text-uppercase btn btn-warning">Купить по акции</a>
						</div>
					</div>
				</div>
				<div style="background-image:url(<?php echo e(asset('images/slide01.jpg')); ?>)">
					<div class="col-md-12">
						<div class="grey-block">
							<p class="text-uppercase">Только в апреле!</p>
							<h2>Металлочерепица<br>
							по сниженной цене</h2>
						</div>
						<div class="clearfix"></div>
						<div class="price-block">
							<p>от 33<sup>50</sup> <small>руб./м.п.</small></p>
						</div>
						<div class="btn-block">
							<a href="share-page.php" class="text-uppercase btn btn-default">Подробнее</a>
							<a href="" class="text-uppercase btn btn-warning">Купить по акции</a>
						</div>
					</div>
				</div>
			</div>
			<div class="owl-prev">
				<img src="<?php echo e(asset('images/icons/left-arrow.png')); ?>" alt="left">
			</div>
			<div class="owl-next">
				<img src="<?php echo e(asset('images/icons/right-arrow.png')); ?>" alt="right">
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="advantages">
					<div class="col-md-3">
						<div class="adv-icon">
							<img src="<?php echo e(asset('images/icons/tools.png')); ?>" alt="icon">
						</div>
						<h5 class="text-uppercase font-bold">Преимущество</h5>
						<p>Подробное описание первого преимущества </p>
					</div>
					<div class="col-md-3">
						<div class="adv-icon">
							<img src="<?php echo e(asset('images/icons/tools.png')); ?>" alt="icon">
						</div>
						<h5 class="text-uppercase font-bold">Преимущество</h5>
						<p>Подробное описание первого преимущества </p>
					</div>
					<div class="col-md-3">
						<div class="adv-icon">
							<img src="<?php echo e(asset('images/icons/tools.png')); ?>" alt="icon">
						</div>
						<h5 class="text-uppercase font-bold">Преимущество</h5>
						<p>Подробное описание первого преимущества </p>
					</div>
					<div class="col-md-3">
						<div class="adv-icon">
							<img src="<?php echo e(asset('images/icons/tools.png')); ?>" alt="icon">
						</div>
						<h5 class="text-uppercase font-bold">Преимущество</h5>
						<p>Подробное описание первого преимущества </p>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 product-carousel-block">
				<h2 class="title">Хиты продаж</h2>
				<div class="owl-prev fa fa-angle-left"></div>
				<div class="owl-next fa fa-angle-right"></div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-12">
				<div class="product-slider">
					<div>
						<div class="image-block" style="background-image: url(<?php echo e(asset('images/products/product01.jpg')); ?>);">
							<a href="product-page.php">ПОДРОБНЕЕ<span class="fa fa-long-arrow-right"></span></a>
						</div>
						<div class="info-block">
							<h4>Металлочерепица Монтеррей</h4>
							<p>от <span class="orange-color">25.00<small>руб./ м.п</small></span></p>
						</div>
						<div class="status-block status-new">
							<span>Новинка</span>
						</div>
						<a data-toggle="modal" href="#buy" class="btn btn-warning text-uppercase"><span class="fa fa-shopping-cart"></span>Заказать</a>
					</div>
					<div>
						<div class="image-block" style="background-image: url(<?php echo e(asset('images/products/product01.jpg')); ?>);">
							<a href="product-page.php">ПОДРОБНЕЕ<span class="fa fa-long-arrow-right"></span></a>
						</div>
						<div class="info-block">
							<h4>Металлочерепица Монтеррей</h4>
							<p>от <span class="orange-color">25.00<small>руб./ м.п</small></span></p>
						</div>
						<div class="status-block status-share">
							<span>Скидка</span>
						</div>
						<a data-toggle="modal" href="#buy" class="btn btn-warning text-uppercase"><span class="fa fa-shopping-cart"></span>Заказать</a>
					</div>
					<div>
						<div class="image-block" style="background-image: url(<?php echo e(asset('images/products/product01.jpg')); ?>);">
							<a href="product-page.php">ПОДРОБНЕЕ<span class="fa fa-long-arrow-right"></span></a>
						</div>
						<div class="info-block">
							<h4>Металлочерепица Монтеррей</h4>
							<p>от <span class="orange-color">25.00<small>руб./ м.п</small></span></p>
						</div>
						<a data-toggle="modal" href="#buy" class="btn btn-warning text-uppercase"><span class="fa fa-shopping-cart"></span>Заказать</a>
					</div>
					
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row catalog-block">
			<div class="col-md-12">
				<h2 class="title">Каталог</h2>
				<div class="row">
					<div class="col-sm-3">
						<ul>
							<li><a href="catalog-page.php">Металлочерепица</a></li>
							<li><a href="catalog-page.php">Профнастил</a></li>
							<li><a href="catalog-page.php">Рулонная кровля</a></li>
							<li><a href="catalog-page.php">Ондувилла</a></li>
							<li><a href="catalog-page.php">ОСБ Плита</a></li>
							<li><a href="catalog-page.php">Чердачные лестницы</a></li>
							<li><a href="catalog-page.php">Отопление</a></li>
							<li><a href="catalog-page.php">Кирпич</a></li>
							<li><a href="catalog-page.php">Доборные элементы</a></li>
						</ul>
					</div>
					<div class="col-sm-3">
						<ul>
							<li><a href="catalog-page.php">Металлочерепица</a></li>
							<li><a href="catalog-page.php">Профнастил</a></li>
							<li><a href="catalog-page.php">Рулонная кровля</a></li>
							<li><a href="catalog-page.php">Чердачные лестницы</a></li>
							<li><a href="catalog-page.php">Отопление</a></li>
							<li><a href="catalog-page.php">Кирпич</a></li>
							<li><a href="catalog-page.php">Доборные элементы</a></li>
						</ul>
					</div>
					<div class="col-sm-3">
						<ul>
							<li><a href="catalog-page.php">Металлочерепица</a></li>
							<li><a href="catalog-page.php">Профнастил</a></li>
							<li><a href="catalog-page.php">Рулонная кровля</a></li>
							<li><a href="catalog-page.php">Ондувилла</a></li>
							<li><a href="catalog-page.php">ОСБ Плита</a></li>
							<li><a href="catalog-page.php">Чердачные лестницы</a></li>
							<li><a href="catalog-page.php">Отопление</a></li>
							<li><a href="catalog-page.php">Доборные элементы</a></li>
						</ul>
					</div>
					<div class="col-sm-3">
						<ul>
							<li><a href="catalog-page.php">Металлочерепица</a></li>
							<li><a href="catalog-page.php">Профнастил</a></li>
							<li><a href="catalog-page.php">Рулонная кровля</a></li>
							<li><a href="catalog-page.php">Ондувилла</a></li>
							<li><a href="catalog-page.php">Чердачные лестницы</a></li>
							<li><a href="catalog-page.php">Отопление</a></li>
							<li><a href="catalog-page.php">Кирпич</a></li>
							<li><a href="catalog-page.php">Доборные элементы</a></li>
							<li><a href="catalog-page.php">Ондувилла</a></li>
							<li><a href="catalog-page.php">ОСБ Плита</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row company">
			<div class="col-md-12">
				<h2 class="title">О компании «техноконтинент»</h2>
				<hr><br>
				<div class="row">
					<div class="col-md-3">
						<div class="comment-slider-wrapper">
							<h4 class="font-bold text-center">ОТЗЫВЫ</h4>
							<hr style="border-color:#f0623f;">
							<div class="comment-slider text-center">
								<div>
									<div class="comment-block">
										<p><i>“Равным образом укрепление и развитие структуры требуют от нас анализа новых предложений. Задача организации, в особенности же сложившаяся структура организации требуют определения"</i></p>
									</div>
									<div class="comment-author">
										<div class="author-image" style="background-image: url('<?php echo e(asset('images/persons/Jake_Facebook_Profile_Pic_Square_400x400.jpg')); ?>');"></div>
										<h4 class="text-uppercase">Андрей Андреев</h4>
										<p style="color:#b8b8b8">г.Барановичи</p>
									</div>
								</div>
								<div>
									<div class="comment-block">
										<p><i>“Равным образом укрепление и развитие структуры требуют от нас анализа новых предложений. Задача организации, в особенности же сложившаяся структура организации требуют определения"</i></p>
									</div>
									<div class="comment-author">
										<div class="author-image" style="background-image: url('<?php echo e(asset('images/persons/Jake_Facebook_Profile_Pic_Square_400x400.jpg')); ?>');"></div>
										<h4 class="text-uppercase">Андрей Андреев</h4>
										<p style="color:#b8b8b8">г.Барановичи</p>
									</div>
								</div>
								<div>
									<div class="comment-block">
										<p><i>“Равным образом укрепление и развитие структуры требуют от нас анализа новых предложений. Задача организации, в особенности же сложившаяся структура организации требуют определения"</i></p>
									</div>
									<div class="comment-author">
										<div class="author-image" style="background-image: url('<?php echo e(asset('images/persons/Jake_Facebook_Profile_Pic_Square_400x400.jpg')); ?>');"></div>
										<h4 class="text-uppercase">Андрей Андреев</h4>
										<p style="color:#b8b8b8">г.Барановичи</p>
									</div>
								</div>
							</div>
							<div class="owl-nav text-center">
								<div class="owl-prev fa fa-angle-left"></div>
								<div class="owl-next fa fa-angle-right"></div>
							</div>
							<a href="comments.php" class="orange-color more-link">Все отзывы<span class="fa fa-long-arrow-right"></span></a>
						</div>
					</div>
					<div class="col-md-9">
						<h2>Компания «Техноконтинент»</h2>
						<p>Мы - современная компания, производитель кровельных материалов, работающая на белорусском рынке 
						уже 8 лет.</p>
						<p>Основное направление деятельности организации — производство и продажа кровельных материалов различных видов. Однако, помимо материалов, мы предлагаем Вам все необходимые услуги для устройства кровли «под ключ»:</p>
						<p>
						- бесплатный подбор материалов, утеплителей, вентиляции и гидроизоляции;<br>
						- выезд замерщика на место;<br>
						- выполнение всех необходимых расчётов, связанных с кровлей, фасадом, стройматериалами и их монтажом;<br>
						- оперативное изготовление кровельных листов и иных материалов на собственных заводах под заданный размер,
						   что в разы снижает конечную стоимость и позволяет экономить на доставке;<br>
						- доставка заказа на место строительства;<br>
						</p>
						<a href="company.php" class="orange-color more-link">Читать дальше<span class="fa fa-long-arrow-right"></span></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row question">
			<div class="col-md-12 text-center">
				<p>Не нашли ответ на интересующий вопрос?</p>
				<p>Оставьте ваш номер телефона, и наш специалист с радостью ответит на любой вопрос!</p>
				<br>
				<form action="" method="POST" class="form-inline" role="form">
					<div class="form-group">
						<input type="phone" class="form-control" id="" required="required" placeholder="Номер телефона">
					</div>
					<button type="submit" class="btn btn-default">ЗАКАЗАТЬ БЕСПЛАТНУЮ КОНСУЛЬТАЦИЮ</button>
				</form>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 product-carousel-block post-slider-wrapper">
				<h2 class="title">Статьи</h2>
				<div class="owl-prev fa fa-angle-left"></div>
				<div class="owl-next fa fa-angle-right"></div>
			</div>
			<div class="clearfix"></div>
			<div class="col-md-12">
				<div class="post-slider">
					<div class="post">
						<div class="image-block" style="background-image: url(<?php echo e(asset('images/post-image.jpg')); ?>);">
							<div class="post-date text-center">
								<b>1</b>
								<hr style="border-color: #f0623f">
								<p>ИЮН</p>
							</div>
						</div>
						<div class="info-block">
							<h4>Монтаж кровли собственными руками  кровли собственными руками</h4>
							<p>Основное направление деятельности организации — производство и продажа кровельных материалов различных видов. Однако, помимо материалов, мы.</p>
							<a href="article-page.php" class="orange-color more-link">Читать далее<span class="fa fa-long-arrow-right"></span></a>
						</div>
					</div>
					<div class="post">
						<div class="image-block" style="background-image: url(<?php echo e(asset('images/post-image.jpg')); ?>);">
							<div class="post-date text-center">
								<b>4</b>
								<hr style="border-color: #f0623f">
								<p>АВГ</p>
							</div>
						</div>
						<div class="info-block">
							<h4>Монтаж кровли собственными руками</h4>
							<p>Основное направление деятельности организации — производство и продажа кровельных материалов различных видов. Однако, помимо материалов, мы.</p>
							<a href="article-page.php" class="orange-color more-link">Читать далее<span class="fa fa-long-arrow-right"></span></a>
						</div>
					</div>
					<div class="post">
						<div class="image-block" style="background-image: url(<?php echo e(asset('images/post-image.jpg')); ?>);">
							<div class="post-date text-center">
								<b>12</b>
								<hr style="border-color: #f0623f">
								<p>АВГ</p>
							</div>
						</div>
						<div class="info-block">
							<h4>Монтаж кровли собственными руками</h4>
							<p>Основное направление деятельности организации — производство и продажа кровельных материалов различных видов. Однако, помимо материалов, мы.</p>
							<a href="article-page.php" class="orange-color more-link">Читать далее<span class="fa fa-long-arrow-right"></span></a>
						</div>
					</div>
					<div class="post">
						<div class="image-block" style="background-image: url(<?php echo e(asset('images/post-image.jpg')); ?>);">
							<div class="post-date text-center">
								<b>23</b>
								<hr style="border-color: #f0623f">
								<p>АВГ</p>
							</div>
						</div>
						<div class="info-block">
							<h4>Монтаж кровли собственными руками</h4>
							<p>Основное направление деятельности организации — производство и продажа кровельных материалов различных видов. Однако, помимо материалов, мы.</p>
							<a href="article-page.php" class="orange-color more-link">Читать далее<span class="fa fa-long-arrow-right"></span></a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-12 text-center">
				<div class="seo-text text-left">
					<h1>Строительные материалы в барановичах</h1>
					<p>Мы - современная компания, производитель кровельных материалов, работающая на белорусском рынке уже 8 лет.</p>
					<p>Основное направление деятельности организации — производство и продажа кровельных материалов различных видов. Однако, помимо материалов, мы предлагаем Вам все необходимые услуги для устройства кровли «под ключ»:</p>
					<p>- бесплатный подбор материалов, утеплителей, вентиляции и гидроизоляции;<br>
					- выезд замерщика на место;<br>
					- выполнение всех необходимых расчётов, связанных с кровлей, фасадом, стройматериалами и их монтажом;<br>
					- оперативное изготовление кровельных листов и иных материалов на собственных заводах под заданный размер.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio autem aliquam minus laborum aperiam natus eum consequatur asperiores, non cupiditate! Perspiciatis nam ea facilis atque praesentium necessitatibus, quo, distinctio minima error, cupiditate at voluptate delectus reiciendis neque ipsam ab aut placeat quibusdam minus? Ipsam, perspiciatis mollitia repudiandae doloribus architecto illum.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio autem aliquam minus laborum aperiam natus eum consequatur asperiores, non cupiditate! Perspiciatis nam ea facilis atque praesentium necessitatibus, quo, distinctio minima error, cupiditate at voluptate delectus reiciendis neque ipsam ab aut placeat quibusdam minus? Ipsam, perspiciatis mollitia repudiandae doloribus architecto illum.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio autem aliquam minus laborum aperiam natus eum consequatur asperiores, non cupiditate! Perspiciatis nam ea facilis atque praesentium necessitatibus, quo, distinctio minima error, cupiditate at voluptate delectus reiciendis neque ipsam ab aut placeat quibusdam minus? Ipsam, perspiciatis mollitia repudiandae doloribus architecto illum.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio autem aliquam minus laborum aperiam natus eum consequatur asperiores, non cupiditate! Perspiciatis nam ea facilis atque praesentium necessitatibus, quo, distinctio minima error, cupiditate at voluptate delectus reiciendis neque ipsam ab aut placeat quibusdam minus? Ipsam, perspiciatis mollitia repudiandae doloribus architecto illum.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio autem aliquam minus laborum aperiam natus eum consequatur asperiores, non cupiditate! Perspiciatis nam ea facilis atque praesentium necessitatibus, quo, distinctio minima error, cupiditate at voluptate delectus reiciendis neque ipsam ab aut placeat quibusdam minus? Ipsam, perspiciatis mollitia repudiandae doloribus architecto illum.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio autem aliquam minus laborum aperiam natus eum consequatur asperiores, non cupiditate! Perspiciatis nam ea facilis atque praesentium necessitatibus, quo, distinctio minima error, cupiditate at voluptate delectus reiciendis neque ipsam ab aut placeat quibusdam minus? Ipsam, perspiciatis mollitia repudiandae doloribus architecto illum.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio autem aliquam minus laborum aperiam natus eum consequatur asperiores, non cupiditate! Perspiciatis nam ea facilis atque praesentium necessitatibus, quo, distinctio minima error, cupiditate at voluptate delectus reiciendis neque ipsam ab aut placeat quibusdam minus? Ipsam, perspiciatis mollitia repudiandae doloribus architecto illum.</p>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row partners">
			<div class="col-md-12 partners-wrapper">
				<div class="owl-prev fa fa-angle-left"></div>
				<div class="owl-next fa fa-angle-right"></div>
				<div class="partners-slider">
					<div><img src="<?php echo e(asset('images/partners/8824310-fedex-logo-650-a542d8629a-1484575865.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/google_logo_2015.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo_blum.png')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo-kronospan.png')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/8824310-fedex-logo-650-a542d8629a-1484575865.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/google_logo_2015.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo_blum.png')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo-kronospan.png')); ?>" alt="logo"></div><div><img src="images/partners/8824310-fedex-logo-650-a542d8629a-1484575865.jpg" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/google_logo_2015.jpg')); ?>" alt="logo"></div>
					<div><img src="<?php echo e(asset('images/partners/logo_blum.png')); ?>" alt="logo"></div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>