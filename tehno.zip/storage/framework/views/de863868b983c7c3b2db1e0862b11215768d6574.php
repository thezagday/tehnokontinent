  
<?php $__env->startSection('content'); ?>
<div class="layout-content">
    <div class="layout-content-body">
        <h1 class="title-bar-title">Редактирование раздела "Слайдер"</h1>
        <p class="title-bar-description">Тут вы можете добавить информацию в раздел "Слайдер"</p>
        <div class="row">
            <div class="col-md-8">
                <div class="demo-form-wrapper">
                    <form action="add_slider" method="post" class="form form-horizontal" enctype="multipart/form-data">
              <ul class="mail-list">
                  <?php echo e(csrf_field()); ?>

                <?php $__currentLoopData = $shares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $share): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="mail-list-item">
                  <label class="mail-list-checkbox custom-control custom-control-primary custom-checkbox">
                      <input class="custom-control-input" type="checkbox" name="ids[]" value="<?php echo e($share->id); ?>">
                    <span class="custom-control-indicator pos-r"></span>
                  </label>
                  <a class="mail-list-link" href="" data-toggle="tab">
                    <div class="mail-list-name"><?php echo $share->title; ?></div>
                    <div class="mail-list-content">
                      <span class="mail-list-subject"><?php echo $share->short_body; ?></span>
                    </div>
                    <div class="mail-list-name"><?php echo $share->price; ?></div>
                  </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
                        
                    <div class="form-group">
                        <label class="col-sm-3 control-label" for="form-control-1"></label>
                            <div class="col-sm-9">
                                <button type="submit" class="btn-primary" id="input_btn">Добавить</button>
                            </div>
                    </div>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>