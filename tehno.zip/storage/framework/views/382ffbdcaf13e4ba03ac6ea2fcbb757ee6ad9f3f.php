  
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('_common._banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="container-fluid">
    <div class="row breadcrumb-wrapper">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li>
                    <a href="/">Главная</a>
                </li>
                <li class="active">О Компании</li>
            </ol>
        </div>
    </div>
</div>
<div class="container-fluid page-content company">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-uppercase">О Компании</h1>
            <div>
                <h2><?php echo $material->title; ?></h2>
                <p><?php echo $material->short_body; ?></p>
            </div>
            <div class="baguetteBox row">
                <div class="col-xs-12 col-sm-6 col-md-4 sert-image-block">
                    <a href="images/company-image.jpg" style="background-image: url('images/company-image.jpg');"></a>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 sert-image-block">
                    <a href="images/company-image.jpg" style="background-image: url('images/company-image.jpg');"></a>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 sert-image-block">
                    <a href="images/company-image.jpg" style="background-image: url('images/company-image.jpg');"></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div>
                <p><?php echo $material->body; ?></p>
            </div>
            <div class="clearfix"></div>
            <div class="product-carousel-block">
                <h2 class="title">Отзывы о нас</h2>
                <div class="owl-prev fa fa-angle-left"></div>
                <div class="owl-next fa fa-angle-right"></div>
            </div>
            <div class="clearfix"></div>
            <div>
                <div class="product-slider text-center">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="comment-block">
                            <p><i><?php echo $comment->short_body; ?></i></p>
                        </div>
                        <div class="comment-author">
                            <div class="author-image" style="background-image: url('images/persons/Jake_Facebook_Profile_Pic_Square_400x400.jpg');"></div>
                            <h4 class="text-uppercase"><?php echo $comment->name; ?></h4>
                            <p style="color:#b8b8b8"><?php echo $comment->city; ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a href="comments" class="orange-color more-link">Все отзывы<span class="fa fa-long-arrow-right"></span></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>