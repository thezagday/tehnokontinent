<?php if(DB::table('catalogs')->where('parent',$catalog->id)->first()!= null): ?>
    <li class="sidenav-item">
        <a href="#" aria-haspopup="true" aria-expanded="false">
            <span class="sidenav-icon icon icon-plus-square"></span>
            <span class="sidenav-label"><?php echo e($catalog->title); ?></span>
        </a>
                
<?php else: ?>
    <li class="sidenav-item">
        <a href="read_products?parent=<?php echo e($catalog->id); ?>">
            <span class="sidenav-icon icon icon-minus-square"></span>
            <span class="sidenav-label"><?php echo e($catalog->title); ?></span>
        </a>
                
<?php endif; ?>
<?php if(count(App\Catalogs::find($catalog->id)->get_childrens) > 0): ?>
            <ul class="sidenav-subnav collapse">
	    <?php $__currentLoopData = App\Catalogs::find($catalog->id)->get_childrens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <?php echo $__env->make('partials.admin_catalog', $catalog, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </ul>
<?php endif; ?>
</li>
