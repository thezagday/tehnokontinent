  
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('_common._banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <div class="container-fluid">
    <div class="row breadcrumb-wrapper">
        <div class="col-md-12">
            <ol class="breadcrumb">
                <li>
                    <a href="/">Главная</a>
                </li>
                <li>
                    <a href="catalog">Каталог</a>
                </li>
                <li>
                    <a href="catalog_page">Металлочерепица</a>
                </li>
                <li>
                    <a href="catalog_page">Белорусская</a>
                </li>
                <li class="active">Акссессуары</li>
            </ol>
        </div>
    </div>
</div>
<div class="container-fluid page-content">
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-sm-3 view-mode">
                    <a href="catalog_page" class="fa fa-th active"></a>
                    <a href="catalog_page_list" class="hidden-xs fa fa-th-list"></a>
                </div>
                <div class="col-sm-3 filter-products">
                    <p class="font-regular">Показано:
                        <select name="" id="" class="inline-select">
                            <option value="" selected>10</option>
                            <option value="">20</option>
                            <option value="">30</option>
                        </select>
                        <label for="select-count">
                            <b class="caret"></b>
                        </label>
                        из 45
                    </p>
                </div>
                <div class="col-sm-6 filter-products">
                    <p class="font-regular">Сортировать по:
                        <select name="" id="" class="inline-select select-width-auto">
                            <option value="" selected>Цене по возрастанию</option>
                            <option value="">Цене по убыванию</option>
                            <option value="">Названию</option>
                        </select>
                        <label for="select-count">
                            <b class="caret"></b>
                        </label>
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3">
               
                    <?php echo $__env->make('_common._menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    
                </div>
                <div class="col-md-9">
                    <div class="row">
                        <?php if(count($accessories)==0): ?>
                        <div class="col-md-4 product-block">
                            <div>
                                <div class="image-block" style="background-image: url(images/no_photo.gif);">
                                    <a href="product_page?id=">ПОДРОБНЕЕ<span class="fa fa-long-arrow-right"></span></a>
                                </div>
                                <div class="info-block">
                                    <h4>Акссессуаров нет</h4>
                                    <p>от <span class="orange-color"><small>руб./ м.п</small></span></p>
                                </div>
                                <a data-toggle="modal" href="#buy" class="btn btn-warning text-uppercase"><span class="fa fa-shopping-cart"></span>Заказать</a>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <?php endif; ?>    
                        <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 product-block">
                            <div>
                                <div class="image-block" style="background-image: url(images/products/product01.jpg);">
                                    <a href="product_page?id=<?php echo e($accessory->id); ?>">ПОДРОБНЕЕ<span class="fa fa-long-arrow-right"></span></a>
                                </div>
                                <div class="info-block">
                                    <h4><?php echo e($accessory->title); ?></h4>
                                    <p>от <span class="orange-color"><?php echo e($accessory->price); ?><small>руб./ м.п</small></span></p>
                                </div>
                                <a data-toggle="modal" href="#buy" class="btn btn-warning text-uppercase"><span class="fa fa-shopping-cart"></span>Заказать</a>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-12 text-center">
                <ul class="pagination">
                    <li><a href="#">&laquo;</a></li>
                    <li><a href="#" class="active">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li><a href="#">&raquo;</a></li>
                </ul>
            </div>
            <div class="clearfix"></div>
            <div class="text-center">
                <div class="seo-text text-left">
                    <h2><?php echo $material->title; ?></h2>
                    <p><?php echo $material->body; ?></p>
                </div>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>