<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class products_colors_product extends Model
{
    //
}
