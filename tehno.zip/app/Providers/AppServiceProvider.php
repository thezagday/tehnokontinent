<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(255);
        $this->ComposeMenu();
        $this->ComposeMainMenu();
        $this->ComposeParentCatalogs();
        $this->ComposeContacts();
        $this->ComposeServices();
        $this->ComposeModals();
        
        /*Admin*/
        $this->ComposeAdminCatalog();
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
    private function ComposeMenu()
    {
        view()->composer('index', function($view)
        {
            $view->with('menu', \App\Menu::all());
        });
    }
    
    private function ComposeMainMenu()
    {
        view()->composer('index', function($view)
        {
            $view->with('main_menu', \App\Main_menu::all());
        });
    }
    private function ComposeParentCatalogs()
    {
        view()->composer('index', function($view)
        {
            $view->with('parent_catalogs', DB::table('catalogs')->whereNull('parent')->get());
            //$view->with('parent_catalogs', DB::table('catalogs')->where('parent', '=', 0)->get());
        });
    }
    private function ComposeContacts()
    {
        view()->composer('index', function($view)
        {
            $view->with('contacts', \App\Contacts::all());
        });
    }
    private function ComposeServices()
    {
        view()->composer('index', function($view)
        {
            $view->with('services', \App\Service::all());
        });
    }
    private function ComposeModals()
    {
        view()->composer('index', function($view)
        {
            $view->with('modals', \App\Modal::all());
        });
    }
    private function ComposeAdminCatalog()
    {
        view()->composer('admin', function($view)
        {
            $view->with('catalogs', \App\Catalogs::all());
        });
    }
}
