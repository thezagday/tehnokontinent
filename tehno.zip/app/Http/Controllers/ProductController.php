<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

use \App\Catalogs;
use \App\Material;
use \App\Product;

class ProductController extends Controller
{
    public function products()
    {
        $products = DB::table('products')->where('parent', '=', Input::get('parent'))->get();
        return view('pages.products',['catalogs'=> Catalogs::all(),'products'=>$products,'material'=> Material::find(2)]);
    }
    public function product_page()
    {
        $product = DB::table('products')->where('id','=',Input::get('id'))->first();
                
        $images = DB::table('images_products')->where('parent','=', Input::get('id'))->get();
        //$colors = DB::table('ColorsProduct')->where('parent','=', Input::get('id'))->get();
        
        $colors = Product::find(Input::get('id'))->get_colors;
        
        /*Не используя связи, а находиь руками*/
        //$descriptions = DB::table('descriptions_products')->where('parent','=', Input::get('id'))->get();
        //$accessories = DB::table('accessories')->where('parent','=', Input::get('id'))->get();
        //$instructions = DB::table('instructions_products')->where('parent','=', Input::get('id'))->get();
        //$certificates = DB::table('certificates_products')->where('parent','=', Input::get('id'))->get();
        
        /*Используя связи Laravel 5.4*/
        $descriptions = Product::find(Input::get('id'))->get_descriptions;
        $accessories  = Product::find(Input::get('id'))->get_accessories;
        $instructions = Product::find(Input::get('id'))->get_instructions;
        $certificates = Product::find(Input::get('id'))->get_certificates;
        
        
        $related = Product::take(12)->where('parent', '=', $product->parent)
                                    ->where('id','<>',$product->id)
                                    ->get();
        
        
        return view('pages.product_page',[
            'catalogs'=> Catalogs::all(),
            'product' => $product,
            'images' => $images,
            'colors'=>$colors,
            'descriptions'=>$descriptions,
            'accessories'=>$accessories,
            'instructions' =>$instructions,
            'certificates' =>$certificates,
            'related' => $related,
            'material'=> Material::find(2),
        ]);
    }
}
