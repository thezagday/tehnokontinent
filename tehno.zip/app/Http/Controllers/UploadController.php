<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;

class UploadController extends Controller
{
    
    public function add_item_shares(Request $request)
    {
        if (!(Input::all()))//нормальное условие
        {
            return view ('admin.shares.add_item_shares');
        }
        elseif($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path() . '/images/shares',$file->getClientOriginalName());
            
            DB::table('shares')->insert([
                'title' => Input::get('title'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
                'price'  => Input::get('price'),
                'relevance' =>Input::get('relevance'),
                'img_path' => '/images/shares/'.$file->getClientOriginalName(),
            ]);
        return redirect()->action('AdminController@read_shares');
        }
        else
        {
            DB::table('shares')->insert([
                'title' => Input::get('title'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
                'price'  => Input::get('price'),
                'relevance' =>Input::get('relevance'),
            ]);
            return redirect()->action('AdminController@read_shares');
        }
    }
    public function update_item_shares(Request $request)
    {
        if($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path() . '/images/shares',$file->getClientOriginalName());
            
            $shares = DB::table('shares')->where('id', Input::get('id'))->first();
            if ($shares->img_path != null)
            {
                unlink(public_path() .$shares->img_path);
            }
            DB::table('shares')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                    'price'  => Input::get('price'),
                    'relevance' =>Input::get('relevance'),
                    'img_path' => '/images/shares/'.$file->getClientOriginalName(),
                ]); 
        return redirect()->action('AdminController@read_shares');
        }
        else
        {
            DB::table('shares')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                    'price'  => Input::get('price'),
                    'relevance' =>Input::get('relevance'),
                ]); 
        return redirect()->action('AdminController@read_shares');
        }
        
    }
    
    
    public function add_item_services(Request $request)
    {
        if (!(Input::all()))
        {
            return view ('admin.services.add_item_services');
        }
        elseif ($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path().'/images/services',$file->getClientOriginalName());
            
            DB::table('services')->insert([
                'title' => Input::get('title'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
                'img_path' => '/images/services/'.$file->getClientOriginalName(),
            ]);
            return redirect()->action('AdminController@read_services');
        }
        else
        {
            DB::table('services')->insert([
                'title' => Input::get('title'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
            ]);
            return redirect()->action('AdminController@read_services');
        }
    }
    public function update_item_services(Request $request)
    {
        if ($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path() . '/images/services',$file->getClientOriginalName());
            
            $services = DB::table('services')->where('id', Input::get('id'))->first();
            if ($services->img_path != null)
            {
                unlink(public_path() .$services->img_path);
            }
            
            DB::table('services')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                    'img_path' => '/images/services/'.$file->getClientOriginalName(),
                ]); 
            return redirect()->action('AdminController@read_services');
        }
        else
        {
            DB::table('services')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                ]); 
            return redirect()->action('AdminController@read_services');
        }
    }
    
    
    public function add_item_news(Request $request)
    {
        if (!(Input::all()))
        {
            return view ('admin.news.add_item_news');
        }
        elseif ($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path().'/images/news',$file->getClientOriginalName());
            
            DB::table('news')->insert([
                'title' => Input::get('title'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
                'img_path' => '/images/news/'.$file->getClientOriginalName(),
                'date' => Input::get('date'),
            ]);
            return redirect()->action('AdminController@read_news');
        }
        else
        {
            DB::table('news')->insert([
                'title' => Input::get('title'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
                'date' => Input::get('date'),
            ]);
            return redirect()->action('AdminController@read_news');
        }
    }
    public function update_item_news(Request $request)
    {
        if ($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path() . '/images/news',$file->getClientOriginalName());
            
            $news = DB::table('news')->where('id', Input::get('id'))->first();
            if ($news->img_path != null)
            {
                unlink(public_path() .$news->img_path);
            }
            DB::table('news')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                    'img_path' => '/images/news/'.$file->getClientOriginalName(),
                    'date' => Input::get('date'),
                ]); 
            return redirect()->action('AdminController@read_news');
        }
        else
        {
            DB::table('news')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                    'date' => Input::get('date'),
                ]); 
            return redirect()->action('AdminController@read_news');
        }
    }
    
    
    public function add_item_articles(Request $request)
    {
        if (!(Input::all()))
        {
            return view ('admin.articles.add_item_articles');
        }
        elseif ($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path().'/images/articles',$file->getClientOriginalName());
            
            DB::table('articles')->insert([
                'title' => Input::get('title'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
                'img_path' => '/images/articles/'.$file->getClientOriginalName(),
                'date' => Input::get('date'),
            ]);
            return redirect()->action('AdminController@read_articles');
        }
        else
        {
            DB::table('articles')->insert([
                'title' => Input::get('title'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
                'date' => Input::get('date'),
            ]);
            return redirect()->action('AdminController@read_articles');
        }
    }
    public function update_item_articles(Request $request)
    {
        if ($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path() . '/images/articles',$file->getClientOriginalName());
            
            $articles = DB::table('articles')->where('id', Input::get('id'))->first();
            if ($articles->img_path != null)
            {
                unlink(public_path() .$articles->img_path);
            }
            DB::table('articles')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                    'img_path' => '/images/articles/'.$file->getClientOriginalName(),
                    'date' => Input::get('date'),
                ]); 
            return redirect()->action('AdminController@read_articles');
        }
        else
        {
            DB::table('articles')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                    'date' => Input::get('date'),
                ]); 
            return redirect()->action('AdminController@read_articles');
        }
    }
    
    
    public function add_item_comments(Request $request)
    {
        if (!(Input::all()))
        {
            return view ('admin.comments.add_item_comments');
        }
        elseif($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path().'/images/comments',$file->getClientOriginalName());
            
            DB::table('comments')->insert([
                'name' => Input::get('name'),
                'city' => Input::get('city'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
                'img_path' => '/images/comments/'.$file->getClientOriginalName(),
                'date' => Input::get('date'),
            ]);
            return redirect()->action('AdminController@read_comments');
        }
        else
        {
            DB::table('comments')->insert([
                'name' => Input::get('name'),
                'city' => Input::get('city'),
                'short_body'  => Input::get('short_body'),
                'body' => Input::get('body'),
                'date' => Input::get('date'),
            ]);
            return redirect()->action('AdminController@read_comments');
        }
    }
    public function update_item_comments(Request $request)
    {
        if ($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path() . '/images/comments',$file->getClientOriginalName());
            
            $comments = DB::table('comments')->where('id', Input::get('id'))->first();
            if ($comments->img_path != null)
            {
                unlink(public_path() .$comments->img_path);
            }
            DB::table('comments')
                ->where('id',Input::get('id'))
                ->update([
                    'name' => Input::get('name'),
                    'city' => Input::get('city'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                    'img_path' => '/images/comments/'.$file->getClientOriginalName(),
                    'date' => Input::get('date'),
                ]); 
            return redirect()->action('AdminController@read_comments');
        }
        else
        {
            DB::table('comments')
                ->where('id',Input::get('id'))
                ->update([
                    'name' => Input::get('name'),
                    'city' => Input::get('city'),
                    'short_body'  => Input::get('short_body'),
                    'body' => Input::get('body'),
                    'date' => Input::get('date'),
                ]); 
            return redirect()->action('AdminController@read_comments'); 
        }
    }
    
    
    public function add_images_products(Request $request)
    {
        if($request->isMethod('post'))
        {
            if($request->hasFile('img_path'))
            {
                $file = $request->file('img_path');
                $file->move(public_path() . '/images/images_products',$file->getClientOriginalName());
                
                DB::table('images_products')->insert([
                    'img_path' => '/images/images_products/'.$file->getClientOriginalName(),
                    'parent' => Input::get('parent'),
                ]);
            }
        }
        return redirect('read_images_products?parent='.Input::get('parent'));
    }
    
    
    public function add_item_descriptions_products(Request $request)
    {
        if($request->isMethod('post'))
        {
            if($request->hasFile('img_path'))
            {
                $file = $request->file('img_path');
                $file->move(public_path() . '/images/descriptions_products',$file->getClientOriginalName());
                
                DB::table('descriptions_products')->insert([
                    'title' => Input::get('title'),
                    'body' => Input::get('body'),
                    'img_path' => '/images/descriptions_products/'.$file->getClientOriginalName(),
                    'parent' => Input::get('parent'),
                ]);
            }
        } 
        return redirect('read_descriptions_products?parent='.Input::get('parent'));
    }
    public function update_item_descriptions_products(Request $request)
    {
        if ($request->hasFile('img_path'))
        {
            $file = $request->file('img_path');
            $file->move(public_path() . '/images/descriptions_products',$file->getClientOriginalName());
            
            $descriptions_products = DB::table('descriptions_products')->where('id', Input::get('id'))->first();
            if ($descriptions_products->img_path != null)
            {
                unlink(public_path() .$descriptions_products->img_path);
            }
        
            DB::table('descriptions_products')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'body' => Input::get('body'),
                    'img_path' => '/images/descriptions_products/'.$file->getClientOriginalName(),
            ]); 
        }
        else
        {
            DB::table('descriptions_products')
                ->where('id',Input::get('id'))
                ->update([
                    'title' => Input::get('title'),
                    'body' => Input::get('body'),
            ]);
        }
        return redirect('read_descriptions_products?parent='.Input::get('parent'));
    }
    
    
    public function add_item_certificates_products(Request $request)
    {
        if ($request->isMethod('get'))
        {
            return view ('admin.products.certificates.add_item_certificates_products',['parent' => Input::get('parent') ]);
        }
        elseif($request->isMethod('post'))
        {
            if($request->hasFile('img_path') && $request->hasFile('prev'))
            {
                $file = $request->file('img_path');
                $file->move(public_path() . '/images/certificates_products',$file->getClientOriginalName());
                
                $file_prev = $request->file('prev');
                $file_prev->move(public_path() . '/images/certificates_products_prev',$file_prev->getClientOriginalName());
                
                DB::table('certificates_products')->insert([
                    'title' => Input::get('title'),
                    'img_path' => '/images/certificates_products/'.$file->getClientOriginalName(),
                    'parent' => Input::get('parent'),
                    'prev' => '/images/certificates_products_prev/'.$file_prev->getClientOriginalName(),
                ]);
            }
        } 
        return redirect('read_certificates_products?parent='.Input::get('parent'));
    }
    public function update_item_certificates_products(Request $request)
    {
        if($request->isMethod('post'))
        {
            if($request->hasFile('img_path') && $request->hasFile('prev'))
            {
                $file = $request->file('img_path');
                $file->move(public_path() . '/images/certificates_products',$file->getClientOriginalName());
                
                $file_prev = $request->file('prev');
                $file_prev->move(public_path() . '/images/certificates_products_prev',$file_prev->getClientOriginalName());
                
                //удаляем старую картинку
                $certificates_products = DB::table('certificates_products')->where('id', Input::get('id'))->first();
                if ($certificates_products->img_path != null)
                {
                    unlink(public_path() .$certificates_products->img_path);
                }
                if ($certificates_products->prev != null)
                {
                    unlink(public_path() .$certificates_products->prev);
                }
                
                DB::table('certificates_products')
                        ->where('id', Input::get('id'))
                        ->update([
                    'title' => Input::get('title'),
                    'img_path' => '/images/certificates_products/'.$file->getClientOriginalName(),
                    'prev' => '/images/certificates_products_prev/'.$file_prev->getClientOriginalName(),
                ]);
            }
            elseif($request->hasFile('img_path'))
            {
                $file = $request->file('img_path');
                $file->move(public_path() . '/images/certificates_products',$file->getClientOriginalName());
                
                //удаляем старую картинку
                $certificates_products = DB::table('certificates_products')->where('id', Input::get('id'))->first();
                unlink(public_path() .$certificates_products->img_path);
                
                DB::table('certificates_products')
                        ->where('id', Input::get('id'))
                        ->update([
                    'title' => Input::get('title'),
                    'img_path' => '/images/certificates_products/'.$file->getClientOriginalName(),
                ]);
            }
            elseif($request->hasFile('prev'))
            {
                $file_prev = $request->file('prev');
                $file_prev->move(public_path() . '/images/certificates_products_prev',$file_prev->getClientOriginalName());
                
                //удаляем старую картинку
                $certificates_products = DB::table('certificates_products')->where('id', Input::get('id'))->first();
                unlink(public_path() .$certificates_products->prev);
                
                DB::table('certificates_products')
                        ->where('id', Input::get('id'))
                        ->update([
                    'title' => Input::get('title'),
                    'prev' => '/images/certificates_products_prev/'.$file_prev->getClientOriginalName(),
                ]);
            }
            else
            {
                DB::table('certificates_products')
                        ->where('id', Input::get('id'))
                        ->update([
                    'title' => Input::get('title'),
                ]);
            }
        } 
        return redirect('read_certificates_products?parent='.Input::get('parent'));
    }
    
    
    public function add_item_accessories(Request $request)
    {
        if($request->isMethod('get'))
        {
            return view ('admin.accessories.add_item_accessories');
        }
        else
        {
            if($request->hasFile('img_path'))
            {
                $file = $request->file('img_path');
                $file->move(public_path() . '/images/accessories',$file->getClientOriginalName());
                
                DB::table('accessories')->insert([
                    'title' => Input::get('title'),
                    'body' => Input::get('body'),
                    'price'  => Input::get('price'),
                    'img_path' => '/images/accessories'.$file->getClientOriginalName()
                ]);
            }
        return redirect()->action('AdminController@read_accessories');
        }
    }
    public function update_item_accessories(Request $request)
    {
        if($request->isMethod('post'))
        {
            if($request->hasFile('img_path'))
            {
                $file = $request->file('img_path');
                $file->move(public_path() . '/images/accessories',$file->getClientOriginalName());
                
                //удаляем старую картинку
                $old_image = DB::table('accessories')->where('id', Input::get('id'))->first();
                if ($old_image->img_path != null)
                {
                    unlink(public_path() .$old_image->img_path);
                }
                
                DB::table('accessories')
                        ->where('id',Input::get('id'))
                        ->update([
                    'title' => Input::get('title'),
                    'body' => Input::get('body'),
                    'price' => Input::get('price'),
                    'img_path' => '/images/accessories/'.$file->getClientOriginalName(),
                ]);
            }
            else
            {
                DB::table('accessories')
                        ->where('id',Input::get('id'))
                        ->update([
                    'title' => Input::get('title'),
                    'body' => Input::get('body'),
                    'price' => Input::get('price'),
                ]);
            }
        } 
        return redirect('read_accessories');
    }
    
    
    public function add_instructions_products(Request $request)
    {
        if ($request->isMethod('get'))
        {
            return view ('admin.products.instructions.add_instructions_products',['parent' => Input::get('parent') ]);
        }
        elseif($request->isMethod('post'))
        {
            if($request->hasFile('link'))
            {
                $file = $request->file('link');
                $file->move(public_path() . '/docs',$file->getClientOriginalName());
                
                DB::table('instructions_products')->insert([
                    'title' => Input::get('title'),
                    'link' => '/docs/'.$file->getClientOriginalName(),
                    'parent' => Input::get('parent'),
                ]);
            }
        } 
        return redirect('read_instructions_products?parent='.Input::get('parent'));
    }
}
