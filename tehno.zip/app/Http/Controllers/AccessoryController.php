<?php

namespace App\Http\Controllers;
use App\Accessories;
use App\Catalogs;
use App\Material;
class AccessoryController extends Controller
{
    public function accessories()
    {
        return view ('pages.accessories',['accessories'=> Accessories::all(),'catalogs'=> Catalogs::all(),'material'=> Material::find(2)]);
    }
}
