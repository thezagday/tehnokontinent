<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Share;
use \App\Material;

class ShareController extends Controller
{
    public function shares()
    {
        return view('pages.shares',['shares'=>  Share::all(),'material'=> Material::find(2)]);//смотреть таблицу
    }
    public function share_page(Request $request)
    {
        return view('pages.share_page',['share'=>  Share::find($request->id)]);
    }
}
