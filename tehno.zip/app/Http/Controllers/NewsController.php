<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\News;
use \App\Material;

class NewsController extends Controller
{
    public function news()
    {
        return view('pages.news',['news'=>  News::all(),'material'=> Material::find(2)]);
    }
    public function news_page(Request $request)
    {
        return view('pages.news_page',['news'=>  News::find($request->id)]);
    }
}
