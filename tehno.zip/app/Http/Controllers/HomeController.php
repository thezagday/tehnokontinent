<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\Catalogs;
use App\Comment;
use App\Article;
use App\Advantage;
use App\Material; //текстовый материал 
use App\Bestseller;
use App\Product;

class HomeController extends Controller
{
    public function __construct()
    {
        //$this->middleware('auth');
    }
    public function index()
    {
        /*Хиты продаж*/
        
        $products_ids = Bestseller::all();
        $bestsellers = array();
        if ($products_ids != null)
        {
            foreach ($products_ids as $ids)
            {
                array_push($bestsellers, Product::find($ids->id));
            }
        }
        
        /**/
        $parent_catalogs = DB::table('catalogs')->whereNull('parent')->get();
        //$parent_catalogs = DB::table('catalogs')->where('parent','=', 3)->get();
        
        return view('pages.home',[
            'catalogs'=> Catalogs::all(),
            'count_catalogs'=> Catalogs::count(),
            'comments'=> Comment::all(),
            'articles'=> Article::all(),
            'advantages'=> Advantage::all(),
            'material'=> Material::all(),
            'bestsellers'=>$bestsellers,
            'parent_catalogs'=>$parent_catalogs,
        ]);
    }
    public function company()
    {
        return view('pages.company',['comments'=> Comment::all(),'material'=> Material::find(1)]); //взять материал именно о компании
    }
    public function comments()
    {
        return view('pages.comments',['comments'=> Comment::all(),'material'=> Material::find(2)]);
    }
}
