<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Service;
use \App\Material;

class ServiceController extends Controller
{
    public function services()
    {
        return view('pages.services',['services'=>  Service::all(),'material'=> Material::find(2)]);
    }
    public function service_page(Request $request)
    {
        return view('pages.service_page',['service'=>  Service::find($request->id)]);
    }
}
