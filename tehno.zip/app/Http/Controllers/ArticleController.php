<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Article;
use \App\Material;

class ArticleController extends Controller
{
    public function articles()
    {
        return view('pages.articles',['articles'=>  Article::all(),'material'=> Material::find(2)]);
    }
    public function article_page(Request $request)
    {
        return view('pages.article_page',['article'=>  Article::find($request->id)]);
    }
}
